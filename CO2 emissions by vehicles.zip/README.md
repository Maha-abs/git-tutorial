# CO2 emissions by vehicles

## Description of the project:

Identifying the vehicles that emit the most CO2 is important to identify the technical characteristics that play a role in pollution. Predicting this pollution in advance makes it possible to prevent the appearance of new types of vehicles (new series of cars for example).

## Resources to refer to: 
- ### Data: 
  - In this data set, you will find all the technical characteristics of vehicles marketed in France in 2013, as well as fuel consumption, CO2 emissions and pollutant emissions into the air.
CO2 and pollutant emissions of vehicles marketed in France - data.gouv.fr 
  - In this one: the CO2 emissions of all the cars that come out each year (several hundred thousand vehicles per year, the dataset for new cars from 2019 alone weighs more than 1gb) with a little more info than that govt data
https://www.eea.europa.eu/data-and-maps/data/co2-cars-emission-20 

## Validation conditions for the project: 
- an exploration, data visualization and data pre-processing report ;
- a modeling report ; 
- a final report.

<br/><br/><br/><br/>

## To tackle the data analysis task, these steps followed:

- Data Gathering and Review:
  - Begin by collecting and reviewing the provided datasets. These datasets contain technical characteristics of vehicles marketed in France in 2013, fuel consumption, CO2 emissions, and pollutant emissions into the air.
  - Familiarize yourself with the data structure, variables, and any potential issues.
- Exploration and Data Visualization:
  - Explore the datasets to identify patterns, outliers, and missing values.
  - Create visualizations (such as histograms, scatter plots, and box plots) to gain insights into the data.
- Data Pre-processing:
  - Clean the data by handling missing values, outliers, and inconsistencies.
  - Transform variables if needed (e.g., normalization, encoding categorical features).
- Modeling and Prediction:
  - Build predictive models to estimate CO2 emissions based on technical characteristics.
  - Consider regression techniques (linear regression, decision trees, etc.).
  - Evaluate model performance using appropriate metrics (e.g., RMSE, R-squared).
- Final Report:
  - Summarize your findings, including key insights, model performance, and recommendations.
  - Communicate the impact of technical characteristics on CO2 emissions.

Remember to document your process thoroughly and maintain a structured approach throughout the analysis. Good luck! 🚗🌿